﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using MessagingToolkit.QRCode;
using Spire.Barcode;
using MessagingToolkit.QRCode.Codec;
using MessagingToolkit.QRCode.Codec.Data;

public partial class booking : System.Web.UI.Page
{
    DateTime d1;
    DateTime d2;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\booking.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        con.Open();



        cmd = new SqlCommand("select * from booking1 where busno='" + DropDownList1.SelectedItem.Text + "'", con);

        // cmd.CommandText = "Select * from booking1 where date='" + TextBox3.Text + "' and busno='" + DropDownList1.Text + "'";
       SqlDataReader dr = cmd.ExecuteReader();
       con.Close();
       con.Open();
            cmd.CommandText = "Insert Into booking1 Values('" + DropDownList1.SelectedItem.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox5.Text + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + TextBox9.Text + "')";
            cmd.ExecuteNonQuery();
            Label9.Text = "Booking done successfully!!!";
        string t1="BN :"+DropDownList1.SelectedItem.Text;
        string t2="NAME :"+TextBox2.Text;
        string t3="SD :"+TextBox3.Text;
        string t4="ED : "+TextBox4.Text;
        string t5="Place : "+TextBox5.Text;
        string t6="SP : "+TextBox6.Text;
        string t7="Time :"+TextBox7.Text;
        string t8="AA :"+TextBox8.Text;
        string t9="DN : "+TextBox9.Text; 
       string code =t1+t2+t3+t4+t5+t6+t8+t9;
            QRCodeEncoder encoder = new QRCodeEncoder();

            Bitmap img = encoder.Encode(code);

            img.Save("C:\\Users\\Pradip\\Desktop\\qrcode\\img.jpg", ImageFormat.Jpeg);

            QRImage.ImageUrl = "img.jpg";

            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
            TextBox9.Text = "";

          
            Label9.Text = " ";

            con.Close();
           
         
         

    }
    
    }


