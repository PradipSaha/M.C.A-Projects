import java.applet.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;
//import java.awt.Color;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.Frame;

public class newapp extends Applet implements ActionListener
{
	  
	    JTextArea text;
	   newapp me;
	   JFrame f;
    Label l1 = new Label("ID : ");
    TextField t1 = new TextField(" ",10); 
    
    Label l2 = new Label("First_Name : ");
    TextField t2 = new TextField(" ",20);
    
    Label l3 = new Label("Last_Name : ");
    TextField t3 = new TextField(" ",20);
    
    Label l4 = new Label("Phone_Number : ");
    TextField t4 = new TextField(" ",11);
    
    Label l5 = new Label("Email : ");
    TextField t5 = new TextField(" ",25);
    
    Button b1 = new Button("Submit"+"\n");
	 
    TextField t6 = new TextField(" ",20);
	Button b3 = new Button("Delete Contact"); 
	Label l7 = new Label(" ");
	Button b2 = new Button("Show Contact");
	Button b4 = new Button("Reset");
	 TextArea t7 = new TextArea(5,30);
	Button b5 = new Button("EDIT");
	Label l8 = new Label("****DELETE USING ID****");
	 Button  b6 = new Button("Search");
	
    public void init()
    {
    	setSize(500,500);
    	add(t7);
    	add(b5);
    	b5.addActionListener(this);
    	add(b2);
    	b2.addActionListener(new ButtonListener());
    	add(b4);
    	b4.addActionListener(new ActionListener(){
    	    public void actionPerformed(ActionEvent e){
    	    	t7.setText(" ");
    	    	System.out.println("reset");
    	    }
    	});
    	setBackground(Color.cyan.darker()); 
        setForeground(Color.black); 
    
     b6.addActionListener(this);
     add(b6);
    	l1.setAlignment(Label.CENTER);
    	add(l8);
        add(l1);
        add(t1);     
        add(l2);
        add(t2);    
        add(l3);
        add(t3);
        add(l4);
        add(t4);
        add(l5);
        add(t5);
        b1.addActionListener(this); 
        add(b1);
   	 	add(t6);
   	 	b3.addActionListener(this);
   	 	add(b3);
   	 //	add(jbnSearch);
   	 Frame title = (Frame)this.getParent().getParent();
     title.setTitle("CONTACT MANAGEMENT SYSTEM");
     b1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
              }
     });
     b1.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
        	 if (t1.getText().length()!=0 ) {
        	 }
        	 else{
                 JOptionPane.showMessageDialog(null,"Please enter Valid Phone no");
             }
         }
     });
         
   	 	
	me = this;
    }//end of init

    public void paint(Graphics g) {
    	showStatus("Pradip Saha � 2016-08-12");
    	l1.setLocation(15 , 50);
    	t1.setLocation(150 , 50);
    	l2.setLocation(15 , 75);
    	t2.setLocation(125, 75);
    	l3.setLocation(15 , 110);
    	t3.setLocation(125, 110);
    	l4.setLocation(15, 150);
    	t4.setLocation(125, 150);
    	l5.setLocation(15, 200);
    	t5.setLocation(125, 200);
    	b1.setLocation(50, 250);
    	b5.setLocation(150, 250);
    	b6.setLocation(250,250);
        t6.setLocation(50, 450);        
        b3.setLocation(250, 450);
        t7.setLocation(50, 300);
        b2.setLocation(50, 400);
        b4.setLocation(150, 400);
        l8.setLocation(100,475);
       }
    public void actionPerformed(ActionEvent e)
    {
    	 if(e.getSource()==b1){
             try{
            	 
            	 
            	         if( t1.getText().equals(" ")|| t2.getText().equals(" ") || t3.getText().equals(" ") || t4.getText().equals(" ")||t5.getText().equals(" "))
            	        {
            	 
            	              JOptionPane.showMessageDialog(null,"SOME DETIALS MISSING");
            	             
            	        }else{

            	 System.out.println("I am here");
                 String myDriver = "oracle.jdbc.driver.OracleDriver";
                 String myUrl = "jdbc:oracle:thin:@localhost:1521/XE";
                 Class.forName(myDriver);
                 Connection con = DriverManager.getConnection(myUrl, "system", "admin");
                 String query = "insert into PRADIP.Students (ID, First_Name, Last_Name, Phone_Number, Email)" + " values (?, ?, ?, ?, ?)";
                 PreparedStatement ps = con.prepareStatement(query);
                 ps.setString (1, t1.getText());
                 ps.setString (2, t2.getText());
                 ps.setString (3, t3.getText());
                 ps.setString (4, t4.getText());
                 ps.setString (5, t5.getText());
                 ps.execute();
                 System.out.println("Submited");
                 t7.setText("\n**Contact added**\n");
                 con.close();
                 t1.setText(" ");
                 t2.setText(" ");
                 t3.setText(" ");
                 t4.setText(" ");
                 t5.setText(" ");
            	        }
             }catch(Exception ex){
                  ex.printStackTrace(); 
                  System.out.println(ex.getMessage());
             }
             
         }else if(e.getSource()==b3){
        	
             try{

    	         if( t1.getText().equals(" "))
    	        {
    	 
    	              JOptionPane.showMessageDialog(null,"ID MISSING");
    	             
    	        }else{
            	 System.out.println("deleted am hereaaaaa");
    	  String myDriver = "oracle.jdbc.driver.OracleDriver";
          String myUrl = "jdbc:oracle:thin:@localhost:1521/XE";
          Class.forName(myDriver);
          Connection con = DriverManager.getConnection(myUrl, "system", "admin");
          String query = "DELETE FROM PRADIP.Students WHERE ID=?";
          PreparedStatement ps = con.prepareStatement(query);
          ps.setString (1, t6.getText());
           ps.execute();
          System.out.println("A user was deleted successfully!");
          t7.setText("\n**Contact deleted Succesfully**\n");
          con.close();
          t6.setText(" ");
    	        }
             }catch(Exception ex){
                  ex.printStackTrace(); 
                  System.out.println(ex.getMessage());
             }
         }else if(e.getSource()==b5){
        	 try{

    	         if( t1.getText().equals(" ")|| t2.getText().equals(" ") || t3.getText().equals(" ") || t4.getText().equals(" ")||t5.getText().equals(" "))
    	        {
    	 
    	              JOptionPane.showMessageDialog(null,"SOME DETIALS MISSING");
    	             
    	        }else{
        	 System.out.println("edit am hereaaaaa");
       	  String myDriver = "oracle.jdbc.driver.OracleDriver";
             String myUrl = "jdbc:oracle:thin:@localhost:1521/XE";
             Class.forName(myDriver);
             Connection connn = DriverManager.getConnection(myUrl, "system", "admin");
             String query = "update PRADIP.Students set First_Name=?, Last_Name=?, Phone_Number=?, Email=? WHERE ID=?";
             PreparedStatement ps = connn.prepareStatement(query);
             
             ps.setString (1, t2.getText());
             ps.setString (2, t3.getText());
             ps.setString (3, t4.getText());
             ps.setString (4, t5.getText());
             ps.setString (5, t1.getText());
              ps.execute();
             System.out.println("A user was EDITED successfully!");
             t7.setText("\n**Contact EDITED Succesfully**\n");
             connn.close();
    	        }
             t1.setText(" ");
             t2.setText(" ");
             t3.setText(" ");
             t4.setText(" ");
             t5.setText(" ");
    	        
        	 }catch(Exception ex){
                 ex.printStackTrace(); 
                 System.out.println(ex.getMessage());
            } 
         }else if(e.getSource()==b6){
        		DefaultTableModel dml = new DefaultTableModel();
              	 try{

        	         if( t2.getText().equals(" ") )
        	        {
        	 
        	              JOptionPane.showMessageDialog(null,"FIRST NAME MISSING");
        	             
        	        }else{
              	 System.out.println("connecting for searching");
             	  String myDriver = "oracle.jdbc.driver.OracleDriver";
                   String myUrl = "jdbc:oracle:thin:@localhost:1521/XE";
                   Class.forName(myDriver);
                   Connection connn = DriverManager.getConnection(myUrl, "system", "admin");
                   Statement stmt = connn.createStatement();
                   String m= t2.getText();
                   
                   String query ="SELECT * FROM PRADIP.Students where First_Name= ?";
                   PreparedStatement ps = connn.prepareStatement(query);
                   ps.setString(1, m);
                   ResultSet rs = ps.executeQuery();
                   	  
                      	    	 f=new JFrame("**SEARCH LIST**");
                      	    	 String column[]={"ID","First-NAME","LAST-NAME","PHONE-NUMBER","EMAIL-ID"};
                      		     dml.setColumnIdentifiers(column);
                      	    	 int i=0; 
                   	          while (rs.next()){
                   	        	System.out.println("inside while");
                   	            	 int id = rs.getInt("ID");
                   	            		String first = rs.getString("First_Name");
                   	            	String last = rs.getString("Last_Name");
                   	            	 String phonenumber = rs.getString("Phone_Number");
                   	            	 String email = rs.getString("Email");
                   	                System.out.print(id+"  "+first+" "+last+" "+phonenumber+" "+email);
                   	           	 dml.addRow(  new Object[]{id, first, last, phonenumber, email});
                                    i++;
                                    System.out.println(" "+i);

                   	          }
                   	       JTable jt = new JTable();
                    	     jt.setModel(dml);
                    	     jt.setFillsViewportHeight(true);
                    	     System.out.println("table");
                    	     jt.setBounds(30,40,200,300);
                      		 jt.setLocation(700, 100);
                      
                      		JScrollPane sp=new JScrollPane(jt);
                      		f.add(sp);
                      		f.setSize(1000,500);
                      		f.setVisible(true);
                                 // Close the connection when finished
                                 connn.close();
        	        }
                             }catch (Exception ex){
                             	System.out.println(ex);
                             }
                   	            
    	}else{}
    }

    @SuppressWarnings("deprecation")
	public void getResults() {
    	DefaultTableModel dml = new DefaultTableModel();
	   try {
	       System.out.println("I am here");
	       Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
           }
           catch (Exception e) {
             System.out.println(
               "Unable to register the JDBC Driver.\n" +
               "Make sure the JDBC driver is in the\n" +
               "classpath.\n");
           }

           // This URL specifies we are connecting with a database server
           // on localhost.
           String url = "jdbc:oracle:thin:@localhost:1521/XE";

           // The username / password to connect under.
           String username = "system";
           String password = "admin";

           // Make a connection with the database.
           Connection con;
           try {
             con = DriverManager.getConnection(url, username, password);
           }
           catch (SQLException e) {
             System.out.println(
               "Unable to make a connection to the database.\n" +
               "The reason: " + e.getMessage());
             return;
           }
           
           try {  
	     Statement stmt = con.createStatement();
           
	     // using executeQuery():
	    
	     ResultSet rs = stmt.executeQuery("SELECT * FROM PRADIP.Students "); 
	    	 f=new JFrame("**LIST OF CONTACTS**");
	    	 String column[]={"ID","First-NAME","LAST-NAME","PHONE-NUMBER","EMAIL-ID"};
		     dml.setColumnIdentifiers(column);
	    	 int i=0; 
	     while (rs.next()) {
	    	System.out.println("inside while");
		 int id = rs.getInt("ID");
		 String first = rs.getString("First_Name");
		 String last = rs.getString("Last_Name");
		 String phonenumber = rs.getString("Phone_Number");
		 String email = rs.getString("Email");
		 dml.addRow(  new Object[]{id, first, last, phonenumber, email});
         i++;
         System.out.println(" "+i);
           }
	     JTable jt = new JTable();
	     jt.setModel(dml);
	     jt.setFillsViewportHeight(true);
	     System.out.println("table");
	     jt.setBounds(30,40,200,300);
  		 jt.setLocation(700, 100);
  
  		JScrollPane sp=new JScrollPane(jt);
  		f.add(sp);
  		f.setSize(1000,500);
  		f.setVisible(true);
             // Close the connection when finished
             con.close();
    }
           
           catch (SQLException e) {
             System.out.println(
               "An error occured\n" +
               "The SQLException message is: " + e.getMessage());
             return;
	   }
    }
    class ButtonListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
	    me.getResults();
	}
	
    }

    }
