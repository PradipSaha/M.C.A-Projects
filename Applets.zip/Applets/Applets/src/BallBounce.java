//import header files 
import java.applet.*; 
// applet is essential as the whole project is  
 import java.awt.*;  
import java.awt.event.*; 
import java.util.Random;

import oracle.net.aso.r;
 // to handle applet events
 //Package Declarations   
 public class BallBounce extends Applet implements Runnable  
 {  
 Random r = new Random(); 
// Generate Random number to fill the ball with random colors at  different positions   
 int x = 10, y = 10,dia1 = 0, dia2 = 0;
 int higt = 500 , widt = 500;  
 public void init()  
 {  
 Thread th = new Thread(this); 
 // creates thread for better animation.  
   th.start(); 
   //starts thread
 }  
 public void run()  
 {  
 while(true)  
 {  
 try 
 // handle exceptions
 {  
 repaint();  
 Thread.sleep(50);  
 // the time interval for ball to change its  position is 50 milli seconds.   
 // setting ball at different positions of applet screen
if( x < widt - 100)
 x += 5;  
 if( y < higt - 100)  
 y += 5;  
 if( x > widt - 100)  
 x = widt - 100;  
 if( y > higt - 100)  
 y = higt - 100;  
 dia1 += 10;  
 dia2 += 10;  
 }  
 catch(Exception e)  
 {
System.out.println("Ball is out of the screen");
}  
 }  
 }  
 public void paint(Graphics g)  
 //To draw the ball on the applet  screen
 {  
 Dimension d = getSize();  
 higt = d.height;  
 widt = d.width;  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
// set the random colors for the ball at the different positions on  the screen
 g.fillArc(x,20,100,100,dia1,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(x,20,100,100,dia1 + 90,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(x,20,100,100,dia1 + 180,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(x,20,100,100,dia1 + 270,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(10, y, 100, 100, dia2 ,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(10,y,100,100, dia2 + 90,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(10,y,100,100,dia2 + 180,90);  
 g.setColor(new Color(r.nextInt(255),r.nextInt(255),r.nextInt(255)));  
 
 g.fillArc(10,y,100,100,dia2 + 270,90);  
 }  
 }
