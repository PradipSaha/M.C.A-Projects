//package asn1;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

class Contact implements Serializable
    {
    	 private String FName;
    	 private String LName;
    	 private String Nname;
    	 private String EMail;
    	 private String Address;
    	 private String PhoneNo1;
		 private String PhoneNo2;
		 private String PhoneNo3;
    	 private String Webpage;
    	 private String Bday;

    	 public void setDetails(String fname, String lname, String nname,String email, String address, String phone1,String phone2,String phone3, String web, String bday)
    	     {
    	     	  FName = fname;
    	     	  LName = lname;
    	     	  Nname = nname;
    	     	  EMail = email;
    	     	  Address = address;
    	     	  PhoneNo1 = phone1;
				  PhoneNo2 = phone2;
				  PhoneNo3 = phone3;
    	     	  Webpage = web;
    	     	  Bday = bday;
             }


         public String getFName()
             {
             	  return FName;
             }

         public String getLName()
             {
             	  return LName;
             }

         public String getNname()
             {
             	  return Nname;
             }

          public String getEMail()
             {
             	  return EMail;
             }

          public String getAddress()
             {
             	  return Address;
             }

          public String getPhoneNo1()
             {
             	  return PhoneNo1;
             }
		  public String getPhoneNo2()
             {
             	  return PhoneNo2;
             }
			public String getPhoneNo3()
             {
             	  return PhoneNo3;
             }

          public String getWebpage()
             {
             	  return Webpage;
             }

          public String getBday()
             {
             	  return Bday;
             }


    }
