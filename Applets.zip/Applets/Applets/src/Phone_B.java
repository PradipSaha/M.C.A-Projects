//package asn1;
import java.io.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

class Phone_B implements ActionListener 
    {
			
          JPanel top_Panel,bottom_Panel;
    	  JScrollPane scroll_Pane;
    	  JFrame frame;

    	  JMenuBar menu_Bar = new JMenuBar(); ;
       	  JMenu menu = new JMenu();
       	  JMenuItem menu_Item;

       	  Toolkit kit = Toolkit.getDefaultToolkit();
       	  Dimension screen_Size = kit.getScreenSize();
       	  int screen_Height = screen_Size.height;
       	  int screen_Width = screen_Size.width;
		


    	  Phone_B()
    	    {

            	    frame = new JFrame("Phone Book");
            	    frame.setBackground(Color.pink);
					//frame.setSize(800, 550);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.setBounds(0,0,screen_Width, screen_Height-30);
                    addWidgets();
                    frame.show();
								

            }



         public void addWidgets()

            {
            	   	menu_Bar.add(menu);

       	            menu = new JMenu("Options");
       	            menu.setMnemonic('O');
       	            menu_Item = new JMenuItem("Add New Contact");
       	            menu_Item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu_Item = new JMenuItem("Delete Contact");
       	            menu_Item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_MASK));
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu_Item = new JMenuItem("Search Contacts");
       	            menu_Item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu_Item = new JMenuItem("Sort Contacts");
       	            menu_Item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_MASK));
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu_Item = new JMenuItem("View All Contacts");
       	            menu_Item.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, InputEvent.CTRL_MASK));
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu.add(new AbstractAction("Exit")
					   {
						  public void actionPerformed(ActionEvent event)
						  {
							 System.exit(0);
						  }
					   });
   
      	            menu_Bar.add(menu);

       	            menu = new JMenu("Help");

       	            menu_Item = new JMenuItem("Help Contents");
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu_Item = new JMenuItem("About");
       	            menu.add(menu_Item);
       	            menu_Item.addActionListener(this);

       	            menu_Bar.add(menu);

       	            frame.setJMenuBar(menu_Bar);


       	            JPanel top_Panel = new JPanel();
                    JPanel bottom_Panel = new JPanel();

                    //Add Buttons To Bottom Panel

                    JButton AddNew = new JButton("Add New Contact");
                    JButton DeleteContact = new JButton("Delete Contact");
                    JButton SearchContacts = new JButton("Search Contacts");
                    JButton SortContacts = new JButton("Sort Contacts");
                    JButton ViewContactList = new JButton("View All Contacts");

                    JLabel label = new JLabel("<HTML><FONT FACE = ARIAL SIZE = 2><B>Use The options below and In The Menu To Manage Contacts Developed by Krupalsinh Zala");                    //Add Action Listener
                    AddNew.addActionListener(this);
                    DeleteContact.addActionListener(this);
                    SearchContacts.addActionListener(this);
                    SortContacts.addActionListener(this);
                    ViewContactList.addActionListener(this);

                    top_Panel.add(label);

                    bottom_Panel.add(AddNew);
                    bottom_Panel.add(DeleteContact);
                    bottom_Panel.add(SearchContacts);
                    bottom_Panel.add(SortContacts);
                    bottom_Panel.add(ViewContactList);

                    frame.getContentPane().add(top_Panel,BorderLayout.NORTH);
                    frame.getContentPane().add(bottom_Panel,BorderLayout.SOUTH);
                    //frame.setResizable(false);
					



            }


         public static void main(String args[])
            {
            	Phone_B add = new Phone_B();
            }


    	 OperationHandler oh = new OperationHandler();

    	 public void actionPerformed(ActionEvent ae)
    	    {
    	        if(ae.getActionCommand() == "Add New Contact")
    	            {
    	                 oh.AddNew();

    	            }

    	        else  if(ae.getActionCommand() == "Search Contacts")
    	            {
    	                 oh.SearchContacts();

    	            }

    	        else  if(ae.getActionCommand() == "Sort Contacts")
    	            {
    	                 oh.SortContacts();

    	            }

    	        else  if(ae.getActionCommand() == "Delete Contact")
    	            {
    	                  oh.DeleteContact();

    	            }

    	        else  if(ae.getActionCommand() == "View All Contacts")
    	            {

    	                  oh.ViewAllContacts();

    	            }

    	        else  if(ae.getActionCommand() == "About")
    	            {
    	                  JOptionPane.showMessageDialog(frame, "\tRoll no :173 \nKrupalsinh Zala","About Phone Book",JOptionPane.INFORMATION_MESSAGE);

    	            }
    	        else  if(ae.getActionCommand() == "Help Contents")
    	            {
    	                try
    	                 {
    	                     oh.showHelp();
    	                 }
    	                catch(IOException e)
    	                 {
    	                 }

    	            }
    	    }     

				
    }




